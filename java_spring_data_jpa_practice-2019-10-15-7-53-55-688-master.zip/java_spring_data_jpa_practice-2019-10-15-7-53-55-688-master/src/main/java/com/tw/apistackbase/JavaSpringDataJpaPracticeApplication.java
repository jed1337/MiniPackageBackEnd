package com.tw.apistackbase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSpringDataJpaPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaSpringDataJpaPracticeApplication.class, args);
	}
}
